import math
import time
import csv
import numpy as np

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import TwistStamped
from tf2_ros import Buffer, TransformListener
from pynput import keyboard
from enum import Enum

class RobotState(Enum):
    RUNNING = 1
    PAUSED = 2

class LemniscataController(Node):
    def __init__(self):
        super().__init__("lemniscata_controller")

        self.robot_state = RobotState.RUNNING
        self.servo_pub = self.create_publisher(TwistStamped, "/servo_server/delta_twist_cmds", 10)
        
        self.tf_buffer = Buffer()
        self.tf_listener = TransformListener(self.tf_buffer, self)

        # --- PARÁMETROS ROS 2 (Requisito Task B) ---
        self.declare_parameter("kp", [2.5, 2.5, 2.5])
        self.declare_parameter("kd", [0.6, 0.6, 0.6])
        self.declare_parameter("ki", [0.1, 0.1, 0.1])
        self.declare_parameter("max_speed", 0.10)
        self.declare_parameter("deadband", 0.002)
        
        self.declare_parameter("radius", 0.06)
        self.declare_parameter("frequency", 0.06)
        
        self.center = None
        self.start_time = self.get_clock().now()
        
        # Memoria PID
        self.prev_error = np.zeros(3)
        self.integral_error = np.zeros(3)
        self.prev_time = self.get_clock().now()

        # CSV Logger (Vital para Task C y la evaluación)
        filename = f"lab_data_{int(time.time())}.csv"
        self.csv_file = open(filename, "w", newline="")
        self.csv_writer = csv.writer(self.csv_file)
        self.csv_writer.writerow(["time", "x_des", "y_des", "z_des", "x_act", "y_act", "z_act", "vx_cmd", "vy_cmd", "vz_cmd"])
        self.get_logger().info(f"Guardando datos en: {filename}")

        self._start_keyboard()
        self.timer = self.create_timer(0.02, self._loop)

    def _start_keyboard(self):
        def on_press(key):
            if hasattr(key, "char") and key.char == "p":
                self.robot_state = RobotState.PAUSED if self.robot_state == RobotState.RUNNING else RobotState.RUNNING
                if self.robot_state == RobotState.PAUSED:
                    self.servo_pub.publish(TwistStamped())
        self.keyboard_listener = keyboard.Listener(on_press=on_press)
        self.keyboard_listener.start()

    def _read_pose(self):
        try:
            trans = self.tf_buffer.lookup_transform("link_base", "link_eef", rclpy.time.Time())
            return np.array([trans.transform.translation.x, trans.transform.translation.y, trans.transform.translation.z])
        except Exception:
            return None

    def _lemniscata_target(self, t_sec: float):
        # Task A: Trayectoria continua (Lemniscata de Gerono) con "Soft Start"
        cx, cy, cz = self.center
        w = 2.0 * math.pi * self.get_parameter("frequency").value
        r = self.get_parameter("radius").value
        
        # Soft start: rampa de 0 a 1 en los primeros 3 segundos
        ramp = min(max(t_sec / 3.0, 0.0), 1.0)
        
        a = ramp * r * math.sin(w * t_sec)
        b = ramp * r * math.sin(w * t_sec) * math.cos(w * t_sec)

        return np.array([cx + a, cy + b, cz])

    def _servo_to(self, target_pos: np.ndarray, t_sec: float):
        current = self._read_pose()
        if current is None: return

        now = self.get_clock().now()
        dt = (now - self.prev_time).nanoseconds / 1e9
        if dt <= 0.0: dt = 1e-6

        # Leer parámetros PID
        kp = np.array(self.get_parameter("kp").value)
        kd = np.array(self.get_parameter("kd").value)
        ki = np.array(self.get_parameter("ki").value)
        max_speed = self.get_parameter("max_speed").value
        deadband = self.get_parameter("deadband").value

        # --- PID Core ---
        error = target_pos - current
        d_error = (error - self.prev_error) / dt
        self.integral_error += error * dt

        v_unclamped = kp * error + ki * self.integral_error + kd * d_error
        v_clamped = np.clip(v_unclamped, -max_speed, max_speed)

        # --- Task B Bonus: Anti-windup (Clamping) ---
        for i in range(3):
            if v_unclamped[i] != v_clamped[i]: # Si el motor se saturó
                if np.sign(error[i]) == np.sign(v_unclamped[i]):
                    self.integral_error[i] -= error[i] * dt # Congela la integración

        # --- Task B: Deadband ---
        active_mask = np.abs(error) > deadband
        v = np.where(active_mask, v_clamped, 0.0)
v[2] = 0.0  # Bloquear movimiento en Z
        # Publicar comando al robot
        cmd = TwistStamped()
        cmd.header.stamp = now.to_msg()
        cmd.header.frame_id = "link_base"
        cmd.twist.linear.x, cmd.twist.linear.y, cmd.twist.linear.z = float(v[0]), float(v[1]), float(v[2])
        self.servo_pub.publish(cmd)

        # Guardar datos para reporte y evaluación
        self.csv_writer.writerow([t_sec, target_pos[0], target_pos[1], target_pos[2], current[0], current[1], current[2], v[0], v[1], v[2]])

        self.prev_error = error
        self.prev_time = now

    def _loop(self):
        if self.center is None:
            p = self._read_pose()
            if p is not None:
                self.center = p.copy()
                self.start_time = self.get_clock().now()
                self.prev_time = self.start_time
            return

        if self.robot_state == RobotState.RUNNING:
            t = (self.get_clock().now() - self.start_time).nanoseconds / 1e9
            target = self._lemniscata_target(t)
            self._servo_to(target, t)

def main(args=None):
    rclpy.init(args=args)
    node = LemniscataController()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        node.csv_file.close()
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == "__main__":
    main()
